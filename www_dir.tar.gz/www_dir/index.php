<?php
echo "<h1>¡Servidor Web de Palermo Funcionando!</h1>";
echo "<p>Trabajo Practico - Redes y Servicios</p>";
echo "<img src='logo.png' alt='Logo del TP'>";
phpinfo();
?>
