#!/bin/bash
if [ "$1" == "-help" ]; then
   echo "Uso: $0 <origen> <destino>"; exit 0
fi
ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%md)
NOMBRE=$(basename "$ORIGEN")
tar -czf "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz" -C "$(dirname "$ORIGEN")" "$NOMBRE"
